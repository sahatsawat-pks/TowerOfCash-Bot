// Mock database module
const mockDb = {
    getUser: jest.fn(),
    createUser: jest.fn(),
    updateStats: jest.fn(),
    getLeaderboard: jest.fn(),
    getEventMode: jest.fn().mockResolvedValue(false), // Default to false
    run: jest.fn(),
    get: jest.fn(),
    get: jest.fn(),
    all: jest.fn()
};

module.exports = mockDb;
